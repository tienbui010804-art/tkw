<?php
    //checkCategoryName
    function checkCategoryName($category_id, $category_name) {
        include './connectdb.php';
        $checkName = true;
        $categorys = mysqli_query($con, "select * from `category` where CategoryID != '{$category_id}'");
        while($row = mysqli_fetch_array($categorys)) {
            if(strtolower($row['CategoryName']) == strtolower($category_name)) {
                $checkName = false;
                break;
            }
        }
        mysqli_close($con);
        return $checkName;
    }

    //Them
    if(isset($_GET['enableQuery'])  && isset($_POST['submit']) && $_POST['submit'] == 'insert') {
        include './connectdb.php';
        $category_id = $_POST['category-id'];
        $category_name = trim($_POST['category-name']);
        $category_desc = trim($_POST['category-desc']);
        $category_status = $_POST['status'];

        if(checkCategoryName($category_id, $category_name)) {
            $result = mysqli_query($con, "insert into `category` (`CategoryID`, `CategoryName`, `Description`, `Status`) values ('{$category_id}', '{$category_name}', '{$category_desc}', {$category_status});");
            mysqli_close($con);
            if($result) {
                echo "<script>
                    alert('Thêm danh mục mới có mã {$category_id} thành công!');
                    window.location.href = 'category-manager.php';
                </script>";
            }
        } else {
            echo "<script>
                    alert('Thêm thất bại! Do tên danh mục {$category_name} đã tồn tại!');
                    window.location.href = 'category-manager.php';
                 </script>";
        }
    }

    //Sua
    if(isset($_GET['enableQuery'])  && isset($_POST['submit']) && $_POST['submit'] == 'edit') {
        include './connectdb.php';
        $checkName = true;
        $category_id = $_POST['category-id'];
        $category_name = trim($_POST['category-name']);
        $category_desc = trim($_POST['category-desc']);
        $category_status = $_POST['status'];

        if(checkCategoryName($category_id, $category_name)) {
            $result = mysqli_query($con, "update `category` 
                                      set `CategoryName` = '{$category_name}', `Description` = '{$category_desc}', `Status` = {$category_status}
                                      where `CategoryID` = '{$category_id}';");
            if($category_status == 0) {
                mysqli_query($con, "update `product` set `Status` = 0 where `CategoryID` = '{$category_id}';");
            }
            mysqli_close($con);
            if($result) {
                echo "<script>
                    alert('Sửa danh mục có mã {$category_id} thành công!');
                    window.location.href = 'category-manager.php';
                </script>";
            }
        } else {
            echo "<script>
                    alert('Sửa thất bại! Do tên danh mục {$category_name} đã bị trùng với một danh mục khác!');
                    window.location.href = 'category-manager.php';
                 </script>";
        }
    }

?>

<?php
include './sidebar.php';
include './container-header.php';
$keyWord = !empty($_GET['category-search']) ? str_replace("\\", "", $_GET['category-search']) : "";
?>

<script>
    eventForSideBar(2);
    setValueHeader("Danh mục");
</script>
<div class="category">
    <div class="category__header">
        <form class="category-header__search" autocomplete="off">
            <input name="category-search" type="text" placeholder="Từ khóa tên.." value="<?= $keyWord ?>">
            <button name="button-search" type="submit" class="category-header-search__link"><span class="material-symbols-outlined">search</span></button>
        </form>
        <?php
            include './connectdb.php';
            $result = mysqli_query($con, "select `CategoryID` from `category` order by `CategoryID` desc limit 1");
            mysqli_close($con);
            $row = mysqli_fetch_array($result);
            if($row != null) {
                $num = substr($row['CategoryID'], 3);
                $num++;
                $newCategoryId = 'BR' . str_pad($num, 3, '0', STR_PAD_LEFT);
            } else {
                $newCategoryId = 'BR001';
            }
        ?>
        <button class="category-header__insert" onclick="displayInsertCategoryModal('<?= $newCategoryId ?>');">Thêm danh mục</button>
    </div>

    <table class="category__table">
        <thead>
            <th>Mã</th>
            <th>Tên danh mục</th>
            <th>Mô tả</th>
            <th>Trạng thái</th>
            <th>Cập nhật</th>
        </thead>
        <tbody>
            <!-- Load danh sach category len tu db -->
            <?php
                include './connectdb.php';
                //Khoi tao cac bien phan trang
                $item_per_page = 8;
                $current_page = !empty($_GET['page']) ? $_GET['page']: 1;
                $offset = ($current_page - 1) * $item_per_page;
                $records = mysqli_query($con, "select * from `category` where CategoryName regexp '{$keyWord}'");
                $num_page = ceil($records->num_rows/$item_per_page);

                $result = mysqli_query($con, "select * from `category` where CategoryName regexp '{$keyWord}' order by CategoryID desc limit {$item_per_page} offset {$offset}");
                
                if($result->num_rows > 0) {
                    while($row = mysqli_fetch_array($result)) {
                        ?>
                        <tr id="<?= $row['CategoryID'] ?>">
                            <td><?= $row['CategoryID'] ?></td>
                            <td><?= $row['CategoryName'] ?></td>
                            <td><?= $row['Description'] ?></td>
                            <td><?= $row['Status'] == 1 ? "Hoạt động" : "Ngừng hoạt động" ?></td>
                            <td onclick="displayEditCategoryModal('<?= $row['CategoryID'] ?>');"><span class="category-table__edit material-symbols-outlined">edit</span></td>
                        </tr>
                        <?php
                    }
                } else {
                    ?>
                    <tr>
                        <td colspan="5" style="padding: 16px;">Không có danh mục nào để hiển thị!</td>
                    </tr>
                <?php
                }
                mysqli_close($con);
            ?>
        </tbody>
    </table>

    <div class="paging">
        <?php
        if($current_page > 3) {
            ?>
                <a href="?page=1&category-search=<?= $keyWord ?>" class="paging__item paging__item--hover">First</a>
            <?php
        }
        for ($num = 1; $num <= $num_page; $num++) {
            if($num != $current_page) {
                if($num > $current_page - 3 && $num < $current_page + 3) {
                ?>
                    <a href="?page=<?= $num ?>&category-search=<?= $keyWord ?>" class="paging__item paging__item--hover"><?= $num ?></a>
                <?php
                }
            } else {
                ?>
                <a href="?page=<?= $num ?>&category-search=<?= $keyWord ?>" class="paging__item paging__item--active"><?= $num ?></a>
                <?php
            }
        }
        if($current_page < $num_page - 2) {
            ?>
                <a href="?page=<?= $num_page ?>&category-search=<?= $keyWord ?>" class="paging__item paging__item--hover">Last</a>
            <?php
        }
        ?>
    </div>

    <div class="modal-category">
        <form class="modal-category__container" action="category-manager.php?enableQuery" method="POST" autocomplete="off">
            <div class="modal-category-container__close">
                <span class="material-symbols-outlined">close</span>
            </div>
            <div class="modal-category-container__content">
                <p class="modal-category-container-content__heading">Thêm danh mục Mới</p>

                <label for="modal-category-container-content-id">Mã</label>
                <input name="category-id" type="text" id="modal-category-container-content-id" readonly>

                <label for="modal-category-container-content-name">Tên danh mục *</label>
                <input name="category-name" type="text" id="modal-category-container-content-name">
                <p style="display: none;" class="err modal-category-container-content-name__err"></p>

                <label for="modal-category-container-content-desc">Mô tả *</label>
                <textarea name="category-desc" name="" id="modal-category-container-content-desc" cols="" rows="10"></textarea>
                <p style="display: none;" class="err modal-category-container-content-desc__err"></p>

                <label for="">Trạng thái hoạt động</label>
                <div class="modal-category-container-content__status">
                    <label for="modal-category-container-content-status-true"><input type="radio" id="modal-category-container-content-status-true" name="status" value="1">Hoạt động</label>
                    <label for="modal-category-container-content-status-false"><input type="radio" id="modal-category-container-content-status-false" name="status" value="0">Ngừng hoạt động</label>
                </div>

                <button type="submit" class="modal-category-container-content__btn insert" name="submit" value="insert" onclick="return checkCategoryForm('thêm');">Thêm</button>
                <button type="submit" class="modal-category-container-content__btn edit" name="submit" value="edit" onclick="return checkCategoryForm('sửa');">Sửa</button>
            </div>
        </form>
    </div>
</div>
<script>
    eventCloseModal('modal-category', 'modal-category__container', 'modal-category-container__close');
</script>
<?php include './container-footer.php' ?>
