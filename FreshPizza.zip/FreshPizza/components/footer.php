<?php
echo '
<div class="footer-footer">
<div id="section-2">
    <p class="smalltitlehomeFooter" id="footer-line-1">© 2023. CÔNG TY CỔ PHẦN XÂY DỰNG VÀ ĐẦU TƯ THƯƠNG MẠI Hà NỘI. MST: 0106713191. (Đăng ký lần đầu: Ngày 15 tháng 12 năm 2020, Đăng ký thay đổi ngày 01/01/2023)
        GP số 426/GP-TTĐT do sở TTTT Hà Nội cấp ngày 22/01/2022.</p>
    <p class="smalltitlehomeFooter" id="footer-line-2">Địa chỉ: 296 Hồ Tùng Mậu, Bắc Từ Liêm, Hà Nội, Việt Nam. Điện thoại: 1900.0009. Chịu trách nhiệm nội dung: Lê Minh Anh.</p>
</div>
</div>
';
?>
