<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vũ Trụ Đồng Hồ</title>
  <link rel="shortcut icon" href="assets/Img/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/about_us.css">
    <link rel="stylesheet" href="assets/css/header.css">
    <link rel="stylesheet" href="assets/css/footer.css">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&amp;display=swap&amp;_cacheOverride=1679484892371"
        data-tag="font">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&amp;display=swap"
        data-tag="font">
</head>
  <!--Start: Header-->
  <div id="bar-header">
    <?php
    include("components/header.php");
    ?>
  </div>
  <!--End: Header-->
<body style="position: relative;">
    <div id="container-aboutUs" style="position: relative;top:50px;height: fit-content;width: 100%;display: flex;flex-direction: column;align-items: center;">
        <img src="assets/Img/banner.jpg" width="100%" alt="">
        <div id="main-aboutUs" style="display: flex;flex-direction: row;">
            <div id="img-aboutUs-div" style="">
                <img id="img-aboutUs" src="assets/Img/productImg/pizza chay.jpg" width="300" alt="">
            </div>
            <div id="content-aboutUs" style="display: flex;align-items: center;">
                <p id="text-content-aboutUs" style="text-align: justify;margin-right: 20px;margin-left: 20px;">
                    Fresh Pizza là thương hiệu chuyên cung cấp các món pizza tươi ngon, được làm thủ công mỗi ngày với nguyên liệu chất lượng cao và công thức độc quyền. Với tiêu chí “Tươi mỗi lát – Ngon mỗi miếng”, Fresh Pizza mong muốn mang đến cho khách hàng những trải nghiệm ẩm thực Ý hiện đại, phù hợp khẩu vị người Việt. Tại Fresh Pizza, chúng tôi sử dụng bột bánh được ủ lạnh tự nhiên, phô mai nguyên chất, rau củ tươi và thịt được chọn lọc kỹ lưỡng. Mỗi chiếc pizza được nướng ngay sau khi khách gọi món, đảm bảo lớp vỏ giòn rụm, nhân bánh nóng hổi và đậm đà hương vị.
                    Không chỉ có pizza, Fresh Pizza còn phục vụ mì Ý, salad, đồ uống và tráng miệng – tất cả đều được chế biến từ nguyên liệu sạch, an toàn và mang phong cách ẩm thực châu Âu tinh tế.
                    Với không gian trẻ trung, hiện đại cùng dịch vụ thân thiện, Fresh Pizza là địa điểm lý tưởng cho những buổi gặp gỡ bạn bè, gia đình hoặc đồng nghiệp.
                </p>
            </div>
        </div>
    </div>
      <!--Start: Footer-->
  <div id="my-footer" style="margin-top: 50px;">
    <?php
    include("components/footer.php");
    ?>
  </div>
  <!--End: Footer-->
    <!--start Hiện thanh line-->
    <script>
    var lineHome = document.getElementById("navbarAbout");

    lineHome.style.borderBottom = '2px solid #fff';
    lineHome.style.paddingBottom = '1.15px';
  </script>
  <!--end Hiện thanh line-->
</body>

</html>