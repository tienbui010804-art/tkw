<?php
    //Them
    if(isset($_GET['enableQuery'])  && isset($_POST['submit']) && $_POST['submit'] == 'insert') {
        include "./connectdb.php";
        //Get categoryId from categoryName
        $result = mysqli_query($con, "select CategoryID from `category` where CategoryName = '{$_POST['category']}'");
        $row = mysqli_fetch_array($result);
        //Tao cac attr cua mot san pham
        $categoryId = $row['CategoryID'];
        $productId = $_POST['product-id'];
        $productName = trim($_POST['product-name']);
        $pathImg = $_FILES['product-img']['name'];
        $size = $_POST['size'];
        $importPprice = trim($_POST['import-price']);
        $priceToSell = trim($_POST['price-to-sell']);
        $discount = trim($_POST['discount']) == "" ? 0: trim($_POST['discount']);
        $desc = trim($_POST['desc']);
        $status = trim($_POST['product-status']);

        //Them vao db
        $result1 = mysqli_query($con, "insert into `product` (`ProductID`, `CategoryID`, `ProductName`, `PriceToSell`, `ImportPrice`, `Discount`, `Size`, `Description`, `ProductImg`, `Status`, `CanDel`) values ('{$productId}', '{$categoryId}', '{$productName}', {$priceToSell}, {$importPprice}, {$discount}, '{$size}', '{$desc}', '{$pathImg}', {$status}, 1)");

        //Cap nhat ton kho
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $now = date('Y-m-d H:i:s');
        $result2 = mysqli_query($con, "insert into `product_quantity` (`ProductID`, `Date`, `Quantity`) values ('{$productId}', '{$now}', 0);");

        mysqli_close($con);
        if($result1 && $result2) {
            //Di chuyen anh den thu muc productImg
            //upload file
            $target_dir = "assets/img/productImg/";
            $target_file = $target_dir . basename($pathImg);
            move_uploaded_file($_FILES["product-img"]["tmp_name"], $target_file);
            echo "<script>
                alert('Thêm sản phẩm mới có mã {$productId} thành công!');
                window.location.href = 'product-manage.php';
            </script>";
        }
    }

    //Sua
    if(isset($_GET['enableQuery'])  && isset($_POST['submit']) && $_POST['submit'] == 'edit') {
        include "./connectdb.php";
        //Get categoryId from categoryName
        $result = mysqli_query($con, "select CategoryID from `category` where CategoryName = '{$_POST['category']}'");
        $row = mysqli_fetch_array($result);
        //Tao cac attr cua mot san pham
        $categoryId = $row['CategoryID'];
        $productId = $_POST['product-id'];
        $productName = trim($_POST['product-name']);
        $pathImg = $_FILES['product-img']['name'];
        $size = $_POST['size'];
        $importPprice = trim($_POST['import-price']);
        $priceToSell = trim($_POST['price-to-sell']);
        $discount = trim($_POST['discount']) == "" ? 0: trim($_POST['discount']);
        $desc = trim($_POST['desc']);
        $status = trim($_POST['product-status']);

        if($pathImg == '') {
            $sql = "update `product` 
                    set `CategoryID` = '{$categoryId}', `ProductName` = '{$productName}', `PriceToSell` = {$priceToSell}, `ImportPrice` = {$importPprice}, `Discount` = {$discount}, `Size` = '{$size}', `Description` = '{$desc}', `Status` = {$status} 
                    where `product`.`ProductID` = '{$productId}';";
        } else {
            $sql = "update `product` 
                    set `CategoryID` = '{$categoryId}', `ProductName` = '{$productName}', `PriceToSell` = {$priceToSell}, `ImportPrice` = {$importPprice}, `Discount` = {$discount}, `Size` = '{$size}', `Description` = '{$desc}',`ProductImg` = '{$pathImg}' , `Status` = {$status} 
                    where `product`.`ProductID` = '{$productId}';";
        }

        //Update to db
        $result = mysqli_query($con, $sql);
        mysqli_close($con);
        if($result) {
            if($pathImg != '') {
                //Di chuyen anh den thu muc productImg
                //upload file
                $target_dir = "assets/img/productImg/";
                $target_file = $target_dir . basename($pathImg);
                move_uploaded_file($_FILES["product-img"]["tmp_name"], $target_file);
            }
            echo "<script>
                alert('Sửa sản phẩm có mã {$productId} thành công!');
                window.location.href = 'product-manage.php';
            </script>";
        }
     }

    //Xoa
    if(isset($_GET['action']) && $_GET['action'] = 'del' && !empty($_GET['product-id'])) {
        //Them vao db
        include "./connectdb.php";
        $result2 = mysqli_query($con, "delete from `product_quantity` where ProductID = '{$_GET['product-id']}'");
        $result3 = mysqli_query($con, "delete from `cart` where ProductID = '{$_GET['product-id']}'");
        $result1 = mysqli_query($con, "delete from `product` where ProductID = '{$_GET['product-id']}'");
        mysqli_close($con);
        if($result1 && $result2 && $result3) {
            echo "<script>
                alert('Xóa sản phẩm có mã {$_GET['product-id']} thành công!');
                window.location.href = 'product-manage.php';
            </script>";
        }
    }
?>

<?php
include './sidebar.php';
include './container-header.php';
$keyWord = !empty($_GET['product-search']) ? str_replace("\\", "", $_GET['product-search']) : "";
?>

<script>
    eventForSideBar(3);
    setValueHeader("Sản phẩm");
</script>
<div class="container__product">
    <div class="container-product__header">
        <form class="container-product-header__search" autocomplete="off">
            <input name="product-search" type="text" placeholder="Tên, danh mục, kích cỡ.." value="<?= $keyWord ?>">
            <button name="button-search" type="submit" class="container-product-header-search__link"><span class="material-symbols-outlined">search</span></button>
        </form>
        <?php
            include './connectdb.php';
            $result = mysqli_query($con, "select `ProductID` from `product` order by `ProductID` desc limit 1");
            mysqli_close($con);
            $row = mysqli_fetch_array($result);
            if($row != null) {
                $num = substr($row['ProductID'], 6);
                $num++;
                $newProductId = 'PR' . str_pad($num, 6, '0', STR_PAD_LEFT);
            } else {
                $newProductId = 'PR000001';
            }
        ?>
        <button class="container-product-header__insert" onclick="displayInsertModal('<?= $newProductId ?>');">Thêm sản phẩm</button>
    </div>

    <table class="container-product__table">
        <thead>
            <th>Danh mục<!--  --></th>
            <th>Mã</th>
            <th>Tên sản phẩm</th>
            <th>Ảnh</th>
            <th>Size</th>
            <th>Giá nhập</th>
            <th>Giá bán</th>
            <th>Giảm giá (%)</th>
            <th>Mô tả</th>
            <th>Trạng Thái</th>
            <th>Cập nhật</th>
            <th>Xóa</th>
        </thead>
        <tbody>
            <!-- Load danh sach dong ho len tu csdl -->
            <?php
            include './connectdb.php';
            // Khoi tao cac bien phan trang
            // Câu lệnh !empty($_GET['ten_bien']) trong PHP kiểm tra xem biến có tồn tại trong mảng $_GET hay không và có giá trị khác rỗng hay không. Nếu biến tồn tại và có giá trị, thì biểu thức !empty() trả về giá trị true, nếu không nó trả về giá trị false.
            $item_per_page = 8;
            $current_page = !empty($_GET['page']) ? $_GET['page']: 1;
            $offset = ($current_page - 1) * $item_per_page;
            $records = mysqli_query($con, "select b.CategoryName, p.ProductID, p.ProductName, p.ProductImg, p.Size, p.ImportPrice, p.PriceToSell, p.Discount, p.Description, p.Status, p.CanDel
                                           from `category` as b, `product` as p
                                           where b.CategoryID = p.CategoryID and (p.ProductName regexp '{$keyWord}' or b.CategoryName = '{$keyWord}' or p.Size = '{$keyWord}')");
            $num_page = ceil($records->num_rows / $item_per_page);

            $result = mysqli_query($con, "select b.CategoryName, p.ProductID, p.ProductName, p.ProductImg, p.Size, p.ImportPrice, p.PriceToSell, p.Discount, p.Description, p.Status, p.CanDel
                                          from `category` as b, `product` as p
                                          where b.CategoryID = p.CategoryID and (p.ProductName regexp '{$keyWord}' or b.CategoryName = '{$keyWord}' or p.Size = '{$keyWord}') order by p.ProductID desc limit {$item_per_page} offset {$offset}");

            if($result->num_rows > 0) {
                while ($row = mysqli_fetch_array($result)) {
                    ?>
                        <tr id="<?= $row['ProductID'] ?>">
                            <td><?= $row['CategoryName'] ?></td>
                            <td><?= $row['ProductID'] ?></td>
                            <td><?= $row['ProductName'] ?></td>
                            <td path = "<?= $row['ProductImg'] ?>"><img src="./assets/img/productImg/<?= $row['ProductImg'] ?>" alt="Ảnh sản phẩm"></td>
                            <td><?= $row['Size'] ?></td>
                            <td><?= number_format($row['ImportPrice']) ?></td>
                            <td><?= number_format($row['PriceToSell']) ?></td>
                            <td><?= $row['Discount'] ?></td>
                            <td><?= $row['Description'] ?></td>
                            <td><?= $row['Status'] == 1 ? "Kinh doanh" : "Ngừng kinh doanh"?></td>
                            <?php
                                $checkCategory = mysqli_query($con, "select `status` from `category` where `CategoryName` = '{$row['CategoryName']}';");
                                $checkCategoryResult = mysqli_fetch_array($checkCategory);
                                if($checkCategoryResult['status'] == 1) {
                                    ?>
                                        <td><span class="container-product-table__edit-icon material-symbols-outlined" onclick = "displayEditModal('<?= $row['ProductID'] ?>');">edit</span></td>
                                    <?php
                                } else {
                                    ?>
                                        <td title="Không thể sửa do danh mục của sản phẩm này đã ngừng hoạt động">
                                            <span class="container-product-table__un-del-icon material-symbols-outlined">block</span>
                                        </td>
                                    <?php
                                }
                            ?>
                            
                            <?php 
                                if($row['CanDel'] == 1) { 
                                ?>
                                    <td><span class="container-product-table__del-icon material-symbols-outlined" onclick="displayPopupDel('<?= $row['ProductID'] ?>');">delete</span></td>
                                <?php 
                                } else {
                                ?>
                                    <td title="Không thể xóa">
                                        <span class="container-product-table__un-del-icon material-symbols-outlined">block</span>
                                    </td>
                                <?php
                                }
                            ?>           
                        </tr>
                    <?php
                }
            } else {
                ?>
                    <tr>
                        <td colspan="12" style="padding: 8px 0;">Không có sản phẩm nào để hiển thị!</td>
                    </tr>
                <?php
            }
            mysqli_close($con);
            ?>
        </tbody>
    </table>

    <div class="paging">
        <?php
        if($current_page > 3) {
            $first_page = 1;
            ?>
                <a href="?page=<?= $first_page ?>&product-search=<?= $keyWord ?>" class="paging__item paging__item--hover">First</a>
            <?php
        }
        for ($num = 1; $num <= $num_page; $num++) {
            if($num != $current_page) {
                if($num > $current_page - 3 && $num < $current_page + 3) {
                ?>
                    <a href="?page=<?= $num ?>&product-search=<?= $keyWord ?>" class="paging__item paging__item--hover"><?= $num ?></a>
                <?php
                }
            } else {
                ?>
                <a href="?page=<?= $num ?>&product-search=<?= $keyWord ?>" class="paging__item paging__item--active"><?= $num ?></a>
                <?php
            }
        }
        if($current_page < $num_page - 2) {
            $last_page = $num_page;
            ?>
                <a href="?page=<?= $last_page?>&product-search=<?= $keyWord ?>" class="paging__item paging__item--hover">Last</a>
            <?php
        }
        ?>
    </div>

    <div class="modal">
        <form autocomplete="off" class="modal__product" method="POST" action="product-manage.php?enableQuery" enctype="multipart/form-data">
            <div class="modal-product__container">
                <p class="modal-product-container__heading">Thêm Sản Phẩm Mới</p>

                <div class="modal-product-container__content">
                    <select name="category" id="modal-product-container-content__category">
                        <option value="Danh mục">-- Danh mục * --</option>
                        <?php
                            include "./connectdb.php";
                            $result = mysqli_query($con, "select * from `category` where status = 1");
                            while($row = mysqli_fetch_array($result)) {
                                ?>
                                    <option value="<?= $row['CategoryName'] ?>"><?=$row['CategoryName']?></option>
                                <?php
                            }
                            mysqli_close($con);
                        ?>
                    </select>
                    <p style="display: none;" class="err modal-product-container-content__err-category"></p>

                    <label class="modal-product-container-content_label" for="modal-product-container-content__product-id">Mã sản phẩm</label>

                    <input style="outline: none;" class="modal-product-container-content_input" name="product-id" id="modal-product-container-content__product-id" type="text" readonly>

                    <label class="modal-product-container-content_label" for="modal-product-container-content__product-name">Tên sản phẩm *</label>
                    <input class="modal-product-container-content_input" name="product-name" id="modal-product-container-content__product-name" type="text">
                    <p style="display: none;" class="err modal-product-container-content__err-name"></p>

                    <label class="modal-product-container-content_label mb-8" id="modal-product-container-content__product-img-text">Hình Ảnh *</label>
                    <div class="modal-product-container__img text-center">
                        <label for="modal-product-container-content__product-img">
                            <img src="./assets/img/admin/place-holder-product/image-placeholder.jpg" alt="Ảnh sản phẩm" id="modal-product-container-content__product-img-src">
                        </label>
                        <input type="file" name="product-img" id="modal-product-container-content__product-img" style="display: none;">
                    </div>
                    <p style="display: none;" class="err modal-product-container-content__err-img"></p>

                    <script>
                        var productImg = document.getElementById('modal-product-container-content__product-img');
                        productImg.addEventListener('change', function() {
                            const files = event.target.files;
                            const file = files[0];
                            console.log(URL.createObjectURL(file));
                            let inputImg = document.querySelector('.modal-product-container__img img');
                            inputImg.src = URL.createObjectURL(file);
                        });
                    </script>
                    
                    <label class="modal-product-container-content_label" for="modal-product-container-content__size">Kích cỡ *</label>
                    <input class="modal-product-container-content_input" name="size" id="modal-product-container-content__size" type="text">
                    <p style="display: none;" class="err modal-product-container-content__err-size"></p>
                    

                    <label class="modal-product-container-content_label" for="modal-product-container-content__import-price">Giá nhập *</label>
                    <input class="modal-product-container-content_input" type="number" min="0" name="import-price" id="modal-product-container-content__import-price" onkeydown="eventKeyDownForInputNumber(event);">
                    <p style="display: none;" class="err modal-product-container-content__err-import-price"></p>

                    <label class="modal-product-container-content_label" for="modal-product-container-content__price-to-sell">Giá bán *</label>
                    <input class="modal-product-container-content_input" type="number" min="0" name="price-to-sell" id="modal-product-container-content__price-to-sell" onkeydown="eventKeyDownForInputNumber(event);">
                    <p style="display: none;" class="err modal-product-container-content__err-price-to-sell"></p>

                    <label class="modal-product-container-content_label" for="modal-product-container-content__discount">Giảm giá (%)</label>
                    <input class="modal-product-container-content_input" type="number" name="discount" id="modal-product-container-content__discount" onkeydown="eventKeyDownForInputNumber(event);">
                    <p style="display: none;" class="err modal-product-container-content__err-discount"></p>

                    <label class="modal-product-container-content_label"  for="modal-product-container-content__desc">Mô tả *</label>
                    <textarea class="modal-product-container-content_input" name="desc" cols="68" rows="10" id="modal-product-container-content__desc" name="desc"></textarea>
                    <p style="display: none;" class="err modal-product-container-content__err-desc"></p>

                    <label class="modal-product-container-content_label mb-8" for="">Trạng thái kinh doanh</label>
                    <div class="modal-product-container-content__status">
                        <label for="product-status-true"><input checked type="radio" id="product-status-true"  name="product-status" value="1">Kinh doanh</label>
                        <label for="product-status-false"><input type="radio" id="product-status-false"  name="product-status" value="0">Ngừng kinh doanh</label>
                    </div>
                </div>

                <button onclick="return checkValidateProductForm('thêm');" name="submit" type="submit" class="modal-product-container__btn insert" value="insert" style="display: none;">Thêm</button>
                <button onclick="return checkValidateProductForm('sửa');" name="submit" type="submit" class="modal-product-container__btn edit" value="edit" style="display: none;">Sửa</button>

                <div class="modal-product-container__close">
                    <span class="material-symbols-outlined">close</span>
                </div>
            </div>
        </form>
    </div>

    <script>
        eventCloseModal('modal', 'modal__product', 'modal-product-container__close');
    </script>
</div>
<?php include './container-footer.php' ?>
