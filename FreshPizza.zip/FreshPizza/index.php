<?php
require_once('lib_session.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Fresh Pizza</title>
  <link rel="shortcut icon" href="assets/Img/logo.png" type="image/x-icon">
  <link rel="stylesheet" href="assets/css/home.css">
  <link rel="stylesheet" href="assets/css/header.css">
  <link rel="stylesheet" href="assets/css/footer.css">
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&amp;display=swap&amp;_cacheOverride=1679484892371"
    data-tag="font">
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&amp;display=swap"
    data-tag="font">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.all.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.min.css" rel="stylesheet">
  <script src="sweetalert2.min.js"></script>
  <link rel="stylesheet" href="sweetalert2.min.css">
</head>

<body>
  <!--Start Nut di chuyen-->
  <div id="btnLenXuong" style="position: fixed;z-index: 999;display: flex;flex-direction: column;top:80%;right: 14px;">
    <img id="btn-top" src="assets/img/hoangImg/icons/icons8-slide-up-32.png" alt=""
      style="cursor: pointer;margin-bottom: 10px;">
    <img id="scroll-to-bottom" onclick="scrollToBottom()" src="assets/img/hoangImg/icons/icons8-down-button-32.png"
      alt="" style="cursor: pointer;">
  </div>

  <!--End nut di chuyen-->
  <!--Start: Header-->
  <div id="bar-header">
    <?php
    include("components/header.php");
    ?>
  </div>
  <!--End: Header-->
  <div id="main"
    style="display: flex;flex-direction: column; background-color:#fff; height: fit-content; position: relative; top: 50px;">
    <style>
      #vtdd-logotext {
        display: block;
        width: auto;
        height: 75px;

      }

      #my-footer {
        position: relative;
        top: 50px;
      }
    </style>

    <div id="ỉntroduction" style="display: flex;    background-color: rgba(255, 164, 27, 0.5);
    height: 100px;justify-content: center;">
      <img id="vtdd-logotext" src="assets/Img/productImg/logo_ngang.jpg" alt="">
    </div>
    <!--Begin: Slider-->
    <div class="slider">
      <div class="slide-wrapper">
        <div class="slide">
          <img class="slide-img" src="assets/Img/productImg/pizza xúc xích.jpg" alt="Slide1" />
        </div>
        <div class="slide">
          <img class="slide-img" src="assets/Img/productImg/mybobam.jpg" alt="Slide2" />
        </div>
        <div class="slide">
          <img class="slide-img" src="assets/Img/productImg/sinhtodau.jpg" alt="Slide3" />
        </div>
      </div>
    </div>
    <!--End: Slider-->
    <div style="background-color: #fff;">
      <p class="bigtitlehome" style="text-align:center ;">Các món đang bán</p>
      <div id="productKD" style="margin-top: 30px;margin-left: 50px;margin-right: 50px;">
        <div
          style="width: 200px;height:200px;background-color:rgba(254, 187, 5, 0.5);display: flex;justify-content: center;align-items: center;">
          <div id="pdIphone" style="display:flex ;flex-direction: column;position: relative;">
            <!-- <p onclick="window.location.href='#pizzaCategoryInfo'" class="mediumtitlehome"
              style="cursor: pointer;color:#fff ;text-align: center;background-color: rgba(255, 208, 121, 0.6);position: absolute;width:100% ;top:50%;transform: translateY(-50%);line-height: 1.5;">
              Pizza</p> -->
            <div
              style="cursor: pointer;display: flex;width: 180px;height: 28px;position: absolute;top:50%;transform: translateY(-50%);z-index: 10;">
              <a id="theAtrongHoverMauTim" class="btn-11 mediumtitlehome"
                onclick="window.location.href='#pizzaCategoryInfo'">Pizza</a>
            </div>
            <div
              style="display: flex;width: 180px;height: 28px;position: absolute;top:50%;transform: translateY(-50%);z-index: 9;background-color: #d1c7a7ff;">
            </div>
            <img src="assets/Img/productImg/pizza thịt heo.png" style="opacity: 0.9;" alt=""
              width="180px">
          </div>
        </div>

        <div
          style="width: 200px;height:200px;background-color:rgba(164, 132, 80, 0.5);display: flex;justify-content: center;align-items: center;">
          <div style="width:180px ;height: 180px;background-color: #fff;">
            <div id="pdOppo" style="display:flex ;flex-direction: column;position: relative;">
              <!-- <p onclick="window.location.href='#myCategoryInfo'" class="mediumtitlehome"
                style="cursor: pointer;color:#fff ;text-align: center;background-color: rgba(164, 122, 80, 0.6);position: absolute;width:100% ;top:50%;transform: translateY(-50%);line-height: 1.5;">
                Mỳ Ý</p> -->
              <div
                style="cursor: pointer;display: flex;width: 180px;height: 28px;position: absolute;top:50%;transform: translateY(-50%);z-index: 10;">
                <a id="theAtrongHoverMauTim2" class="btn-11 mediumtitlehome"
                  onclick="window.location.href='#myCategoryInfo'">Mỳ Ý</a>
              </div>
              <div
                style="display: flex;width: 180px;height: 28px;position: absolute;top:50%;transform: translateY(-50%);z-index: 9;background-color: #d1bba7ff;">
              </div>
              <img src="assets/Img/productImg/ff2.jpg" style="opacity: 0.9;" alt="" width="180px">
            </div>
          </div>
        </div>
        <div
          style="width: 200px;height:2020x;background-color:rgba(164, 128, 80, 0.5);display: flex;justify-content: center;align-items: center;">
          <div id="pdPixel" style="display:flex ;flex-direction: column;position: relative;">
            <!-- <p onclick="window.location.href='#douongCategoryInfo'" class="mediumtitlehome"
              style="cursor: pointer;color:#fff ;text-align: center;background-color: rgba(164, 133, 80, 0.6);position: absolute;width:100% ;top:50%;transform: translateY(-50%);line-height: 1.5;">
              Đồ uống</p> -->
            <div
              style="cursor: pointer;display: flex;width: 180px;height: 28px;position: absolute;top:50%;transform: translateY(-50%);z-index: 10;">
              <a id="theAtrongHoverMauTim3" class="btn-11 mediumtitlehome"
                onclick="window.location.href='#douongCategoryInfo'">Đồ uống</a>
            </div>
            <div
              style="display: flex;width: 180px;height: 28px;position: absolute;top:50%;transform: translateY(-50%);z-index: 9;background-color: #d1c4a7ff;">
            </div>
            <img src="assets/Img/productImg/sinhtodau.jpg" style="opacity: 0.9;" alt="" width="180px">
          </div>
        </div>

        <div
          style="width: 200px;height:200px;background-color:rgba(164, 125, 80, 0.5);display: flex;justify-content: center;align-items: center;">
          <div id="pdRealme" style="display:flex ;flex-direction: column;position: relative;">
            <!-- <p onclick="window.location.href='#trangmiengCategoryInfo'" class="mediumtitlehome"
              style="cursor: pointer;color:#fff ;text-align: center;background-color: rgba(191, 149, 66, 0.6);position: absolute;width:100% ;top:50%;transform: translateY(-50%);line-height: 1.5;">
              Tráng miệng</p> -->
            <div
              style="cursor: pointer;display: flex;width: 180px;height: 28px;position: absolute;top:50%;transform: translateY(-50%);z-index: 10;">
              <a id="theAtrongHoverMauTim4" class="btn-11 mediumtitlehome"
                onclick="window.location.href='#trangmiengCategoryInfo'">Tráng miệng</a>
            </div>
            <div
              style="display: flex;width: 180px;height: 28px;position: absolute;top:50%;transform: translateY(-50%);z-index: 9;background-color: #d1c0a7ff;">
            </div>
            <img src="assets/Img/productImg/dessert2.jpg" style="opacity: 0.9;" s alt="" width="180px">
          </div>
        </div>

        <div
          style="width: 200px;height:200px;background-color:rgba(164, 128, 80, 0.5);display: flex;justify-content: center;align-items: center;">
          <div id="pdSamsung" style="display:flex ;flex-direction: column;position: relative;">
            <!-- <p onclick="window.location.href='#gaCategoryInfo'" class="mediumtitlehome"
              style="cursor: pointer;color:#fff ;text-align: center;background-color: rgba(164, 143, 80, 0.6);position: absolute;width:100% ;top:50%;transform: translateY(-50%);line-height: 1.5;">
              Gà</p> -->
            <div
              style="cursor: pointer;display: flex;width: 180px;height: 28px;position: absolute;top:50%;transform: translateY(-50%);z-index: 10;">
              <a id="theAtrongHoverMauTim5" class="btn-11 mediumtitlehome"
                onclick="window.location.href='#gaCategoryInfo'">Món gà</a>
            </div>
            <div
              style="display: flex;width: 180px;height: 28px;position: absolute;top:50%;transform: translateY(-50%);z-index: 9;background-color: #d1bda7ff;">
            </div>
            <img src="assets/Img/productImg/garancay.jpg" style="opacity: 0.9;" alt="" width="180px">
          </div>
        </div>

      </div>
    </div>


    <div id="pizzaCategoryInfo" style="background-color: rgba(248, 200, 79, 0.4); margin-top: 56px; padding-bottom: 56px;">
      <!--<p class="bigtitlehome" style="text-align:center ;margin-top: 50px;">Các món bán chạy</p>-->
      <p class="bigtitlehome" style="text-align:center ;margin-top: 50px;">Pizza thập cẩm</p>
      <div id="productBC">
        <div class="clockCategoryContent">
          <div class="col30">
            <img src="assets/Img/productImg/home-img-1.png" alt="" width="250px" alt="">
          </div>
          <p style="text-align: justify;display: flex;align-items: center;" class="col70 smalltitlehome">Pizza thập cẩm là loại pizza kết hợp nhiều loại topping khác nhau, mang đến hương vị phong phú và đa dạng cho người ăn. Các thành phần phổ biến bao gồm xúc xích, thịt nguội, thịt bò, phô mai Mozzarella, nấm, ớt chuông, hành tây và dứa.  </p>
        </div>

        <hr id="myCategoryInfo" style="margin-top: 50px;margin-bottom: 50px;">

        <p class="bigtitlehome" style="text-align:center ;">Mỳ sốt thịt bằm</p>
        <div class="clockCategoryContent">
          <div class="col30">
            <img src="assets/Img/productImg/ff2.jpg" alt="" width="250px" alt="">
          </div>
          <p style="text-align: justify;display: flex;align-items: center;" class="col70 smalltitlehome">Mì sốt thịt bằm (Bolognese) là món ăn nổi tiếng của Ý, gồm sợi mì spaghetti kết hợp với sốt thịt bằm đậm đà từ thịt bò xay, cà chua và các loại rau củ. Món ăn này chinh phục thực khách bởi sự hòa quyện giữa sợi mì dai mềm và sốt sánh mịn, thơm lừng, rất phổ biến trong các nhà hàng và dễ dàng chế biến tại nhà.  </p>
        </div>
        <hr id="douongCategoryInfo" style="margin-top: 50px;margin-bottom: 50px;">

        <p class="bigtitlehome" style="text-align:center ;">Sinh tố dâu</p>
        <div class="clockCategoryContent">
          <div class="col30">
            <img src="assets/Img/productImg/sinhtodau.jpg" alt="" width="250px" alt="">
          </div>
          <p style="text-align: justify;display: flex;align-items: center;" class="col70 smalltitlehome">Sinh tố dâu là thức uống giải nhiệt thơm ngon, bổ dưỡng, được làm từ dâu tây xay nhuyễn kết hợp với sữa, sữa chua, hoặc các loại trái cây khác và đá viên. Thức uống này không chỉ mang lại hương vị chua ngọt hấp dẫn mà còn cung cấp nhiều vitamin và khoáng chất, hỗ trợ tăng cường sức đề kháng, cải thiện làn da và có lợi cho sức khỏe của phụ nữ mang thai.  </p>
        </div>
      
        <hr id="gaCategoryInfo" style="margin-top: 50px;margin-bottom: 50px;">

        <p class="bigtitlehome" style="text-align:center ;">Gà sốt cay</p>
        <div class="clockCategoryContent">
          <div class="col30">
            <img src="assets/Img/productImg/garancay.jpg" alt="" width="250px" alt="">
          </div>
          <p style="text-align: justify;display: flex;align-items: center;" class="col70 smalltitlehome">Gà sốt cay là một món ăn phổ biến, đặc trưng bởi lớp vỏ ngoài giòn rụm và phần thịt gà mềm bên trong, được bao phủ bởi một lớp sốt cay ngọt đậm đà. Món ăn này có thể có nhiều biến thể tùy theo vùng miền và phong cách chế biến, nhưng nổi bật nhất là gà sốt cay kiểu Hàn Quốc (gà yangnyeom) sử dụng tương ớt gochujang, và gà sốt cay kiểu Mỹ (thường xuất hiện ở Nashville) với sốt cay đặc trưng.  </p>
        </div>
    </div>


  </div>

  <!--Start: Footer-->
  <div id="my-footer">
    <?php
    include("components/footer.php");
    ?>
  </div>
  <!--End: Footer-->
  <script>
    var btnTop = document.getElementById("btn-top");
    window.addEventListener("scroll", function () {
      if (window.pageYOffset > 0) {
        btnTop.style.display = "block";
      } else {
        btnTop.style.display = "none";
      }
    });

    btnTop.addEventListener("click", function () {
      window.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    });

    function scrollToBottom() {
      window.scrollTo(0, document.body.scrollHeight);
    }

    var scrollToBottomButton = document.getElementById("scroll-to-bottom");

    window.onscroll = function () {
      if (window.pageYOffset == document.body.scrollHeight - window.innerHeight) {
        scrollToBottomButton.style.display = "none";
      } else {
        scrollToBottomButton.style.display = "block";
      }
    };

  </script>
  <!--start Hiện thanh line-->
  <script>
    var lineHome = document.getElementById("navbarHome");

    lineHome.style.borderBottom = '2px solid #fff';
    lineHome.style.paddingBottom = '1.15px';
  </script>
  <!--end Hiện thanh line-->

  <?php
    if (isset($_SESSION['loginSuccess'])) {
      echo "<script>
      Swal.fire({
        title: 'Thông báo!',
        text: 'Đăng nhập thành công!',
        icon: 'success',
        confirmButtonText: 'Xác nhận'
      })
      </script>";
      unset($_SESSION['loginSuccess']);
    }
  ?>
  <?php
    if (isset($_SESSION['changeUserInfor'])) {
      echo "<script>
      Swal.fire({
        title: 'Thông báo!',
        text: 'Thay đổi thông tin thành công, vui lòng đăng nhập lại!',
        icon: 'success',
        confirmButtonText: 'Xác nhận'
      })
      </script>";
      unset($_SESSION['changeUserInfor']);
    }
  ?>
    <?php
    if (isset($_SESSION['changePassWordSuccess'])) {
      echo "<script>
      Swal.fire({
        title: 'Thông báo!',
        text: 'Đổi mật khẩu thành công, vui lòng đăng nhập lại!',
        icon: 'success',
        confirmButtonText: 'Xác nhận'
      })
      </script>";
      unset($_SESSION['changePassWordSuccess']);
    }
  ?>
   <?php
    if (isset($_SESSION['signupSuccess'])) {
      echo "<script>
      Swal.fire({
        title: 'Thông báo!',
        text: 'Đăng ký tài khoản thành công!',
        icon: 'success',
        confirmButtonText: 'Xác nhận'
      })
      </script>";
      unset($_SESSION['signupSuccess']);
    }
  ?>
</body>

</html>
