-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th10 12, 2025 lúc 04:54 PM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `freshpizza`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `admin`
--

CREATE TABLE `admin` (
  `AdminID` varchar(4) NOT NULL,
  `FullName` varchar(100) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `admin`
--

INSERT INTO `admin` (`AdminID`, `FullName`, `Email`, `Password`) VALUES
('AD01', 'Võ Quang Đăng Khoa', 'dangkhoa1509@gmail.com', '123456'),
('AD02', 'Nguyễn Minh Thu', 'nguyenminhthu03092004@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cart`
--

CREATE TABLE `cart` (
  `UserID` varchar(8) NOT NULL,
  `ProductID` varchar(8) NOT NULL,
  `Quantity` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `cart`
--

INSERT INTO `cart` (`UserID`, `ProductID`, `Quantity`) VALUES
('US000012', 'PR000001', 2);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `category`
--

CREATE TABLE `category` (
  `CategoryID` varchar(5) NOT NULL,
  `CategoryName` varchar(100) NOT NULL,
  `Description` text DEFAULT NULL,
  `Status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `category`
--

INSERT INTO `category` (`CategoryID`, `CategoryName`, `Description`, `Status`) VALUES
('BR001', 'Pizza', 'Các loại pizza được chế biến từ nguyên liệu tươi ngon, đa dạng hương vị và phong cách Ý truyền thống.', 1),
('BR002', 'Mỳ', 'Nhiều loại mỳ phong phú như mỳ Ý, mỳ cay Hàn Quốc, mỳ xào, mỳ nước... phù hợp khẩu vị mọi thực khách.', 1),
('BR003', 'Khai vị', 'Các món khai vị hấp dẫn như salad, khoai tây chiên, soup, giúp kích thích vị giác trước bữa ăn chính.', 1),
('BR004', 'Tráng miệng', 'Orient – Thương hiệu đồng hồ Nhật Bản thuộc Seiko Epson được thành lập vào năm 1950. Đồng hồ Orient chính hãng được chế tác từ vật liệu thượng hạng, bộ máy tiêu chuẩn cao cấp, độ hoàn thiện tinh xảo. Orient sở hữu tệp khách hàng rộng khắp nhờ thiết kế đa dạng trong dây đeo (dây da, kim loại), kiểu dáng (tròn, mặt vuông, chữ nhật), phong cách (Quartz, automatic, cơ tự động lộ máy), vật liệu (sapphire, kính cứng) hay màu sắc (đỏ, xanh, đen,…).Các món ngọt nhẹ như bánh, kem, trái cây và chè, mang đến kết thúc hoàn hảo cho bữa ăn.', 1),
('BR005', 'Đồ uống', 'Thức uống đa dạng gồm nước ép, sinh tố, cà phê, trà sữa và nước ngọt tươi mát cho mọi lựa chọn.', 1),
('BR006', 'Gà', 'Các món gà thơm ngon như gà rán, gà nướng, gà sốt cay, mang đến hương vị đậm đà và hấp dẫn.', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `inventoryreceivingvoucher`
--

CREATE TABLE `inventoryreceivingvoucher` (
  `InID` varchar(10) NOT NULL,
  `SupplierID` varchar(8) NOT NULL,
  `Date` date NOT NULL,
  `Total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `inventoryreceivingvoucher`
--

INSERT INTO `inventoryreceivingvoucher` (`InID`, `SupplierID`, `Date`, `Total`) VALUES
('IN00000001', 'SU000005', '2025-04-30', 640000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order`
--

CREATE TABLE `order` (
  `OrderID` varchar(10) NOT NULL,
  `UserID` varchar(8) NOT NULL,
  `OderDate` datetime NOT NULL,
  `ShippingFee` int(11) NOT NULL,
  `OrderDiscount` int(11) NOT NULL,
  `OrderTotal` double NOT NULL,
  `Address` varchar(150) NOT NULL,
  `PaymentID` varchar(4) NOT NULL,
  `VoucherID` varchar(5) NOT NULL,
  `OrderStatus` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `order`
--

INSERT INTO `order` (`OrderID`, `UserID`, `OderDate`, `ShippingFee`, `OrderDiscount`, `OrderTotal`, `Address`, `PaymentID`, `VoucherID`, `OrderStatus`) VALUES
('OR00000002', 'US000001', '2023-05-16 04:09:04', 30000, 10000, 1000000, '521/91E CMT8#P13#Q10#HCM', 'PA01', 'VO001', 'S01'),
('OR00000003', 'US000001', '2023-05-16 04:09:04', 30000, 10000, 1000000, '521/91E CMT8#P13#Q10#HCM', 'PA01', 'VO001', 'S02'),
('OR00000004', 'US000001', '2023-05-16 04:09:04', 30000, 10000, 1000000, '521/91E CMT8#P13#Q10#HCM', 'PA01', 'VO001', 'S02'),
('OR00000005', 'US000001', '2023-05-16 04:09:04', 30000, 10000, 1000000, '521/91E CMT8#P13#Q10#HCM', 'PA01', 'VO001', 'S03'),
('OR00000006', 'US000001', '2023-05-16 04:09:04', 30000, 10000, 1000000, '521/91E CMT8#P13#Q10#HCM', 'PA01', 'VO001', 'S04'),
('OR00000007', 'US000001', '2023-05-16 04:09:04', 30000, 10000, 1000000, '521/91E CMT8#P13#Q10#HCM', 'PA01', 'VO001', 'S04'),
('OR00000008', 'US000001', '2023-05-16 04:09:04', 30000, 10000, 1000000, '521/91E CMT8#P13#Q10#HCM', 'PA01', 'VO001', 'S05'),
('OR00000009', 'US000001', '2023-05-16 04:09:04', 30000, 10000, 1000000, '521/91E CMT8#P13#Q10#HCM', 'PA01', 'VO001', 'S05');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `orderstatus`
--

CREATE TABLE `orderstatus` (
  `StatusID` varchar(3) NOT NULL,
  `StatusName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `orderstatus`
--

INSERT INTO `orderstatus` (`StatusID`, `StatusName`) VALUES
('S01', 'Chưa xác nhận'),
('S02', 'Đã xác nhận'),
('S03', 'Đang giao hàng'),
('S04', 'Đã giao hàng'),
('S05', 'Đã hủy');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order_line`
--

CREATE TABLE `order_line` (
  `OrderID` varchar(10) NOT NULL,
  `ProductID` varchar(8) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `UnitPrice` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `payment`
--

CREATE TABLE `payment` (
  `PaymentID` varchar(4) NOT NULL,
  `PaymentName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `payment`
--

INSERT INTO `payment` (`PaymentID`, `PaymentName`) VALUES
('PA01', 'Thanh toán khi nhận hàng'),
('PA02', 'Chuyển khoản ngân hàng');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `product`
--

CREATE TABLE `product` (
  `ProductID` varchar(8) NOT NULL,
  `CategoryID` varchar(5) NOT NULL,
  `ProductName` varchar(300) NOT NULL,
  `PriceToSell` double NOT NULL,
  `ImportPrice` double NOT NULL,
  `Discount` double DEFAULT NULL,
  `Size` varchar(20) NOT NULL,
  `Description` text DEFAULT NULL,
  `ProductImg` varchar(200) NOT NULL,
  `Status` tinyint(1) NOT NULL,
  `CanDel` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `product`
--

INSERT INTO `product` (`ProductID`, `CategoryID`, `ProductName`, `PriceToSell`, `ImportPrice`, `Discount`, `Size`, `Description`, `ProductImg`, `Status`, `CanDel`) VALUES
('PR000001', 'BR001', 'Pizza Hải Sản Nhiệt Đới', 189000, 120000, 0, 'Lớn', 'Pizza với hải sản tươi ngon, phô mai mozzarella béo ngậy và sốt cà chua đặc trưng.', 'pizza hải sản.png\"', 1, 0),
('PR000002', 'BR001', 'Pizza Bò Phô Mai', 175000, 110000, 0, 'Vừa', 'Lớp phô mai kéo sợi hòa quyện cùng bò bằm sốt cay nhẹ, thơm ngon khó cưỡng.', 'pizza phô mai.jpg', 1, 1),
('PR000003', 'BR001', 'Pizza Gà Nướng BBQ', 179000, 115000, 0, 'Lớn', 'Pizza gà nướng sốt BBQ đậm đà, phô mai thơm lừng.', 'pizza gà nấm.jpg', 1, 1),
('PR000004', 'BR001', 'Pizza Rau Củ Chay', 165000, 100000, 0, 'Vừa', 'Pizza chay với ớt chuông, nấm, bắp ngọt, phù hợp cho người ăn lành mạnh.', 'pizza chay.jpg', 1, 1),
('PR000005', 'BR001', 'Pizza Thập Cẩm', 195000, 125000, 0, 'Lớn', 'Tổng hợp hương vị từ hải sản, bò, xúc xích và phô mai béo ngậy.', 'home-img-1.png', 1, 1),
('PR000006', 'BR002', 'Mỳ Ý Sốt Bò Bằm', 95000, 60000, 0, 'Vừa', 'Mỳ Ý tươi kết hợp cùng sốt bò bằm và cà chua chua ngọt, hương vị chuẩn Âu.', 'mybobam.jpg', 1, 1),
('PR000007', 'BR002', 'Mỳ Cay Hàn Quốc', 85000, 55000, 0, 'Vừa', 'Mỳ Hàn cay nồng, kèm chả cá, xúc xích và rau củ, thích hợp cho tín đồ cay.', 'mihan.jpg', 1, 0),
('PR000008', 'BR002', 'Mỳ Trộn Trứng Lòng Đào', 89000, 55000, 0, 'Vừa', 'Mỳ trộn sốt tương đen kết hợp trứng lòng đào béo ngậy.', 'ff3.jpg', 1, 1),
('PR000009', 'BR002', 'Mỳ Ý Kem Nấm', 99000, 65000, 0, 'Vừa', 'Mỳ Ý sốt kem tươi, nấm thơm, vị béo nhẹ và mịn màng.', 'ff2.jpg', 1, 1),
('PR000010', 'BR002', 'Mỳ Udon Thịt Bò', 105000, 70000, 0, 'Lớn', 'Mỳ udon mềm dai, kết hợp nước dùng thanh và thịt bò thơm mềm.', 'miudonbo.jpg', 1, 1),
('PR000011', 'BR003', 'Salad Trộn Dầu Giấm', 65000, 40000, 0, 'Nhỏ', 'Món salad thanh mát với rau tươi, trứng luộc và dầu giấm chua nhẹ.', 'salad.jpg', 1, 1),
('PR000012', 'BR003', 'Khoai Tây Chiên', 55000, 30000, 0, 'Vừa', 'Khoai tây chiên vàng giòn, ăn kèm tương ớt hoặc tương cà hấp dẫn.', 'ff1.jpg', 1, 1),
('PR000013', 'BR003', 'Soup Bí Đỏ', 59000, 35000, 0, 'Nhỏ', 'Soup bí đỏ béo nhẹ, thơm ngọt tự nhiên, dùng nóng.', 'supbido.jpg', 1, 1),
('PR000014', 'BR003', 'Bánh Mì Bơ Tỏi', 45000, 25000, 0, 'Nhỏ', 'Bánh mì nướng giòn tan, phết bơ tỏi thơm lừng.', 'banhmibotoi.jpg', 1, 1),
('PR000015', 'BR003', 'Gỏi Cuốn Tôm Thịt', 50000, 35000, 0, 'Phần', 'Gỏi cuốn tươi mát với tôm, thịt, rau sống, chấm mắm nêm đậm vị.', 'cuongoi.jpg', 1, 1),
('PR000016', 'BR004', 'Bánh Flan Caramel', 25000, 20000, 0, 'Nhỏ', 'Bánh flan mềm mịn, vị trứng sữa béo nhẹ, phủ lớp caramel ngọt thanh.', 'dessert4.jpeg', 1, 1),
('PR000017', 'BR004', 'Kem Vanila', 20000, 15000, 0, 'Nhỏ', 'Kem vanila mát lạnh, thơm dịu, phù hợp cho mọi lứa tuổi.', 'dessert5.jpg', 1, 0),
('PR000018', 'BR004', 'Bánh Tiramisu', 25000, 15000, 0, 'Miếng', 'Bánh Tiramisu hương matcha, vị béo nhẹ, ngọt dịu.', 'dessert3.jpg', 1, 1),
('PR000019', 'BR004', 'Chè Dừa Non', 25000, 15000, 0, 'Ly', 'Chè dừa non thơm béo, kết hợp trân châu và thạch mát lạnh.', 'cheduanon.webp', 1, 1),
('PR000020', 'BR004', 'Bánh Pancake Mật Ong', 20000, 15000, 0, 'Cái', 'Pancake mềm xốp, rưới mật ong vàng óng và bơ tan chảy.', 'dessert2.jpg', 1, 1),
('PR000021', 'BR005', 'Nước Ép Cam Tươi', 35000, 20000, 0, 'Ly', 'Nước ép cam nguyên chất, giàu vitamin C, giúp tăng cường sức đề kháng.', 'fanta..jpg', 1, 1),
('PR000022', 'BR005', 'Trà Sữa Trân Châu', 55000, 40000, 0, 'Ly', 'Trà sữa thơm béo kết hợp trân châu dẻo ngọt, hương vị khó quên.', 'trasuatranchau.jpg', 1, 1),
('PR000023', 'BR005', 'Sinh Tố Dâu', 50000, 30000, 0, 'Ly', 'Sinh tố dâu tươi xay nhuyễn, chua ngọt tự nhiên.', 'sinhtodau.jpg', 1, 1),
('PR000024', 'BR005', 'Cà Phê Sữa Đá', 30000, 20000, 0, 'Ly', 'Cà phê đậm đà, pha sữa đặc béo thơm – món quen thuộc của Việt Nam.', 'caphesuada.jpg', 1, 1),
('PR000025', 'BR006', 'Gà Rán Giòn Cay', 110000, 85000, 0, 'Phần', 'Gà rán giòn rụm, thấm vị cay nhẹ, thích hợp cho bữa ăn nhanh.', 'garancay.jpg', 1, 1),
('PR000026', 'BR006', 'Gà Sốt Mật Ong', 120000, 80000, 0, 'Phần', 'Thịt gà mềm thơm, phủ lớp sốt mật ong ngọt dịu hấp dẫn.', 'gamatong.jpg', 1, 1),
('PR000027', 'BR006', 'Gà Chiên Nước Mắm', 80000, 60000, 0, 'Phần', 'Gà chiên giòn rưới nước mắm tỏi ớt đậm đà, cực kỳ bắt cơm.', 'gachienmam.jpg', 1, 1),
('PR000028', 'BR006', 'Gà Xé Trộn Rau Răm', 70000, 50000, 0, 'Phần', 'Gà xé trộn rau răm, hành phi và nước mắm chua ngọt...', 'gaxetronrauram.jpg', 1, 1),
('PR000029', 'BR006', 'Cánh Gà Chiên Giòn', 120000, 100000, 0, 'Phần', 'Cánh gà chiên vàng giòn, chấm tương ớt cay nồng.', 'canhgachienvang.jpg', 1, 1),
('PR000030', 'BR006', 'Gà nướng muối ớt', 180000, 120000, 0, 'Phần', 'Gà nướng than hoa, ướp muối ớt thơm cay, da giòn thịt mềm.', 'ganuongmuoiot.webp', 1, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `product_quantity`
--

CREATE TABLE `product_quantity` (
  `ProductID` varchar(8) NOT NULL,
  `Date` datetime NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `product_quantity`
--

INSERT INTO `product_quantity` (`ProductID`, `Date`, `Quantity`) VALUES
('PR000001', '2025-10-12 18:45:04', 3),
('PR000007', '2025-10-12 18:45:04', 4),
('PR000017', '2025-10-12 18:45:04', 4);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `receivingdetail`
--

CREATE TABLE `receivingdetail` (
  `InID` varchar(10) NOT NULL,
  `ProductID` varchar(10) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `ReceivingUnitPrice` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `receivingdetail`
--

INSERT INTO `receivingdetail` (`InID`, `ProductID`, `Quantity`, `ReceivingUnitPrice`) VALUES
('IN00000001', 'PR000001', 3, 120000),
('IN00000001', 'PR000007', 4, 55000),
('IN00000001', 'PR000017', 4, 15000);

--
-- Bẫy `receivingdetail`
--
DELIMITER $$
CREATE TRIGGER `trg_receivingdetail_afterdel` AFTER DELETE ON `receivingdetail` FOR EACH ROW update `product` set `CanDel` = 1 where ProductID = old.ProductID and canDel = 0 and ProductID not in (select distinct ProductID from `order_line` where ProductID = old.ProductID) and ProductID not in (select distinct ProductID from `receivingdetail` where ProductID = old.ProductID)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `supplier`
--

CREATE TABLE `supplier` (
  `SupplierID` varchar(8) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `NumberPhone` varchar(10) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `supplier`
--

INSERT INTO `supplier` (`SupplierID`, `Name`, `NumberPhone`, `Address`, `Email`, `Status`) VALUES
('SU000001', 'Công ty ABC', '0987675433', '770 CMT8, P13, Q10, Hồ Chí Minh', 'abccompany@gmail.com', 1),
('SU000002', 'Thịnh Long', '0976543234', '4 Cao Lỗ, P4, Q8, Hồ Chí Minh', 'thinhlong@gmail.com', 1),
('SU000004', 'Công ty rau củ Hà Bắc', '0907876588', 'Lê Văn Việt, Q11, Hồ Chí Minh', 'raucuhabac@gmail.com', 1),
('SU000005', 'Minh Tân', '0908765432', 'Gò Vấp, Hồ Chí Minh', 'minhtan@gmail.com', 1),
('SU000006', 'Đức Tài', '0907865222', 'Chợ Bến Thành, Quận 1, Hồ Chí Minh', 'ductai@gmail.com', 1),
('SU000007', 'Nam Sơn', '0908777888', '33 CMT8, P11, Q10, Hồ Chí Minh', 'namson@gmail.com', 1),
('SU000008', 'Thịnh Hưng', '0393678444', 'Hà Nội', 'thinhhung@gmail.com', 1),
('SU000009', 'Duy Anh', '0987654111', '445, Hoàng Kiếm, Hà Nội', 'duyanh@gmail.com', 1),
('SUP0003', 'Công ty Minh Long', '0911222333', 'Hồ Chí Minh', 'minhlong@gmail.com', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `UserID` varchar(8) NOT NULL,
  `FullName` varchar(50) NOT NULL,
  `NumberPhone` varchar(10) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `HouseRoadAddress` varchar(50) NOT NULL,
  `Ward` varchar(30) NOT NULL,
  `District` varchar(30) NOT NULL,
  `Province` varchar(30) NOT NULL,
  `Status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`UserID`, `FullName`, `NumberPhone`, `Email`, `Password`, `HouseRoadAddress`, `Ward`, `District`, `Province`, `Status`) VALUES
('US000001', 'Võ Văn Hùng', '0907604514', 'vovanhung2864@gmail.com', '123456', '521/91E, CMT8', 'Phường 13', 'Quận 10', 'Thành phố Hồ Chí Minh', 1),
('US000002', 'Nguyễn Văn Đò', '0907604532', 'nguyenvand@example.com', '123456', '45', 'Xã Khuôn Hà', 'Huyện Lâm Bình', 'Tỉnh Tuyên Quang', 1),
('US000003', 'Võ Quang Đăng Khoa', '0907685643', 'dangkhoa2345@gmail.com', '123456', '34', 'Xã Lương Can', 'Huyện Hà Quảng', 'Tỉnh Cao Bằng', 1),
('US000004', 'Thiều Việt Hoàng', '0908675435', 'thieuhoang2346@gmail.com', '123456', '34', 'Phường Bồng Lai', 'Thị xã Quế Võ', 'Tỉnh Bắc Ninh', 1),
('US000006', 'Thiều Bảo Trâm', '0907604999', 'baotram2345@gmail.com', '123456', '61 An Định A', 'Thị trấn Ba Chúc', 'Huyện Tri Tôn', 'Tỉnh An Giang', 1),
('US000007', 'Lê Hồng Cẩm thu', '0327794675', 'camthu@gmail.com', '123456', '1', 'Phường An Hòa', 'Quận Ninh Kiều', 'Thành phố Cần Thơ', 1),
('US000008', 'Lê Ngọc Trâm', '0976543678', 'ngoctram567@gmail.com', '123456', '770 CMT8', 'Phường 05', 'Quận Tân Bình', 'Thành phố Hồ Chí Minh', 1),
('US000009', 'Phạm Cẩm Thơ', '0976548762', 'camtho234@gmail.com', '123456', '521/91E CMT8', 'Phường 13', 'Quận 10', 'Thành phố Hồ Chí Minh', 1),
('US000010', 'Đào Công Trứ', '0327794829', 'congtru2865@gmail.com', '123456', 'Đường 19/5', 'Xã Tân Ân', 'Huyện Cần Đước', 'Tỉnh Long An', 1),
('US000011', 'Nguyễn Minh Thư', '0972836952', 'nguyenminhthu03092004@gmail.com', 'thu03092004', 'vũ đoài', 'Phường Giảng Võ', 'Quận Ba Đình', 'Thành phố Hà Nội', 1),
('US000012', 'Nguyễn Minh Thư', '0962836952', '', '12345678', 'vũ đoài', 'Phường Quang Trung', 'Thành phố Hà Giang', 'Tỉnh Hà Giang', 1),
('US000052', 'Phạm Thị Ba', '0988777666', 'phamb@example.com', '123456', 'Số 9 Lê Lợi', 'Phường 3', 'Quận 1', 'TP.HCM', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `voucher`
--

CREATE TABLE `voucher` (
  `VoucherID` varchar(5) NOT NULL,
  `VoucherName` varchar(50) NOT NULL,
  `Discount` int(11) NOT NULL,
  `Unit` varchar(5) NOT NULL,
  `DateFrom` date NOT NULL,
  `DateTo` date NOT NULL,
  `Status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `voucher`
--

INSERT INTO `voucher` (`VoucherID`, `VoucherName`, `Discount`, `Unit`, `DateFrom`, `DateTo`, `Status`) VALUES
('VO001', '30/4', 5, '%', '2023-04-24', '2023-04-30', 1),
('VO002', '5/5', 200000, '%', '2023-05-04', '2025-05-20', 1),
('VO003', '1/1 Tết Dương Lịch', 1, '%', '2022-01-01', '2022-01-03', 1),
('VO005', 'Ngày thành lập Đảng Cộng Sản Việt Nam 3/2', 2, '%', '2022-02-03', '2022-02-03', 1),
('VO006', 'Ngày Quốc Tế Phụ Nữ 8/3', 3, '%', '2022-03-08', '2022-03-08', 1),
('VO007', 'Ngày sinh của Bác Hồ', 3, '%', '2022-05-19', '2022-05-19', 1),
('VO008', 'Lễ Giáng Sinh', 3, '%', '2022-12-15', '2022-12-25', 1),
('VO009', 'Quốc tế lao động', 3, '%', '2022-05-01', '2022-05-01', 1),
('VO015', 'Mừng lễ 30/4', 100000, 'VNĐ', '2025-04-25', '2025-05-10', 1);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`AdminID`);

--
-- Chỉ mục cho bảng `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`UserID`,`ProductID`),
  ADD KEY `FK_ProductID_Cart` (`ProductID`);

--
-- Chỉ mục cho bảng `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`CategoryID`);

--
-- Chỉ mục cho bảng `inventoryreceivingvoucher`
--
ALTER TABLE `inventoryreceivingvoucher`
  ADD PRIMARY KEY (`InID`),
  ADD KEY `FK_SupplierID` (`SupplierID`);

--
-- Chỉ mục cho bảng `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `FK_Order_User` (`UserID`),
  ADD KEY `FK_Order_VoucherID` (`VoucherID`),
  ADD KEY `FK_Order_Status` (`OrderStatus`),
  ADD KEY `FK_Order_PaymentID` (`PaymentID`);

--
-- Chỉ mục cho bảng `orderstatus`
--
ALTER TABLE `orderstatus`
  ADD PRIMARY KEY (`StatusID`);

--
-- Chỉ mục cho bảng `order_line`
--
ALTER TABLE `order_line`
  ADD PRIMARY KEY (`OrderID`,`ProductID`),
  ADD KEY `FK_OrderLine_ProductID` (`ProductID`);

--
-- Chỉ mục cho bảng `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`PaymentID`);

--
-- Chỉ mục cho bảng `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ProductID`),
  ADD KEY `FK_BrandID` (`CategoryID`);

--
-- Chỉ mục cho bảng `product_quantity`
--
ALTER TABLE `product_quantity`
  ADD PRIMARY KEY (`ProductID`,`Date`);

--
-- Chỉ mục cho bảng `receivingdetail`
--
ALTER TABLE `receivingdetail`
  ADD PRIMARY KEY (`InID`,`ProductID`),
  ADD KEY `FK_ProductID_Re` (`ProductID`);

--
-- Chỉ mục cho bảng `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`SupplierID`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- Chỉ mục cho bảng `voucher`
--
ALTER TABLE `voucher`
  ADD PRIMARY KEY (`VoucherID`);

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `FK_ProductID_Cart` FOREIGN KEY (`ProductID`) REFERENCES `product` (`ProductID`),
  ADD CONSTRAINT `FK_UserID` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);

--
-- Các ràng buộc cho bảng `inventoryreceivingvoucher`
--
ALTER TABLE `inventoryreceivingvoucher`
  ADD CONSTRAINT `FK_SupplierID` FOREIGN KEY (`SupplierID`) REFERENCES `supplier` (`SupplierID`);

--
-- Các ràng buộc cho bảng `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `FK_Order_PaymentID` FOREIGN KEY (`PaymentID`) REFERENCES `payment` (`PaymentID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_Order_Status` FOREIGN KEY (`OrderStatus`) REFERENCES `orderstatus` (`StatusID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_Order_User` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_Order_VoucherID` FOREIGN KEY (`VoucherID`) REFERENCES `voucher` (`VoucherID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Các ràng buộc cho bảng `order_line`
--
ALTER TABLE `order_line`
  ADD CONSTRAINT `FK_OrderLine_OrderID` FOREIGN KEY (`OrderID`) REFERENCES `order` (`OrderID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_OrderLine_ProductID` FOREIGN KEY (`ProductID`) REFERENCES `product` (`ProductID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Các ràng buộc cho bảng `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `FK_BrandID` FOREIGN KEY (`CategoryID`) REFERENCES `category` (`CategoryID`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `product_quantity`
--
ALTER TABLE `product_quantity`
  ADD CONSTRAINT `FK_ProductID` FOREIGN KEY (`ProductID`) REFERENCES `product` (`ProductID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Các ràng buộc cho bảng `receivingdetail`
--
ALTER TABLE `receivingdetail`
  ADD CONSTRAINT `FK_InID` FOREIGN KEY (`InID`) REFERENCES `inventoryreceivingvoucher` (`InID`),
  ADD CONSTRAINT `FK_ProductID_Re` FOREIGN KEY (`ProductID`) REFERENCES `product` (`ProductID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
